import { Stack, Typography } from "@mui/material";
import React from "react";

function SkillsCard() {
  return (
    <>
      <Stack sx={{ backgroundColor: "var( --color-dark-blue)" }}>
        <img src="" alt="" />
        <Typography color={"var(--color-white)"}>HTML</Typography>
      </Stack>
    </>
  );
}

export default SkillsCard;
