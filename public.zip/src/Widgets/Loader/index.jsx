import React from "react";

function Loader() {
  return <span class="loader"></span>;
}

export default Loader;
